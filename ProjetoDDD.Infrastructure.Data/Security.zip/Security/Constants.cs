﻿namespace ProjetoDDD.Infrastructure.Data.Security
{
    public static class Constants
    {
        public const string SharedSecret = "*KapirotoXYZ*";
    }
}
